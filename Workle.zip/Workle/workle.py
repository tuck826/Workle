import tkinter as tk
from tkinter import*
#from tkinter import ttk
import random, time
import pyperclip
import random,ctypes,os
from PIL import ImageTk, Image
import matplotlib.pyplot as plt
from matplotlib import pyplot as plt
import numpy as np
import matplotlib.cm as cm




######GLOBAL VARIABLES########

WordsDoc = "word.txt" #If you have stored locally all together
#Example path if you have it stored in another directory
##r'C:\Users\~Username~\Desktop\~DirectoryName~'


######END OF VARIABLES###########










def play(): ####This function gives the ability to replay over and over again
    global enter,word_var,submitButton,typeSubmission,winWord,listedWinWord
    global aButton,bButton,cButton,dButton,eButton,fButton,gButton,hButton,iButton,jButton,kButton,lButton,mButton,nButton
    global oButton,pButton,qButton,rButton,sButton,tButton,uButton,vButton,wButton,xButton,yButton,zButton
    global fullPath,path,scores1,scores2,scores3,scores4,scores5,scores6,alphabet,attempted,scoreScores,games_played
    global rows,columns,allSpaces,get_display_name,submit,winner,scoreSheet,checkWord,boardPos,unlock,badStuff,word,play,replayGame,badWord,redacted_words
    global suggestions,spacedWordHint,submitLimit,WordsDoc

    
    window = tk.Tk()
    window.title('Workle')
    window.configure(background='#2e5976')
    Font_tuple = ("Century Gothic", 12, "bold")

    def restart(): #The actual restart this window
        window.destroy()
        play()
        
        


    listOfWords = open(WordsDoc,"r").read().splitlines()
    winWord = random.choice(listOfWords)
    print(winWord)

    listedWinWord = list(winWord)


    alphabet = ['aButton','bButton','cButton','dButton','eButton','fButton','gButton','hButton','iButton',
                'jButton','kButton','lButton','mButton','nButton','oButton','pButton','qButton','rButton',
                'sButton','tButton','uButton','vButton','wButton','xButton','yButton','zButton']


    #Scores
    scoreScores = []
    scores1 = []
    scores2 = []
    scores3 = []
    scores4 = []
    scores5 = []
    scores6 = []
    attempted = ['1','2','3','4','5','6']
    games_played = []
    redacted_words = []
   
    #endScores

    word_var=tk.StringVar()
    rows = 6
    columns = 5


    allSpaces = []
    enter = 0

    submitLimit = 0








    ############Functions############        

    def suggest():
        global alphabet,spacedWordHint,typeSubmission,bigVariable


        ####DELETE IN THE LIST#####
        #This function Deletes letters from the list
        def onRightClick(newVar,newVar2):
            global alphabet
            global aButton,bButton,cButton,dButton,eButton,fButton,gButton,hButton,iButton,jButton,kButton,lButton,mButton,nButton
            global oButton,pButton,qButton,rButton,sButton,tButton,uButton,vButton,wButton,xButton,yButton,zButton

            disableFromList = newVar2 + 'Button'

            if globals()[disableFromList].cget('bg') == 'light gray' or globals()[disableFromList].cget('bg') == 'green' :
                globals()[disableFromList].config(fg='#000001')
            else:
                globals()[disableFromList].config(bg='#565656',fg = '#000001')
            
            vanish = globals()[newVar]
            vanish.grid_forget()


#####ADD TO LIST#######

            #This function adds the words to the list
        def addToList(theWord):
            global typeSubmission,bigVariable

            updatedStuff = globals()[theWord].cget('text')
            typeSubmission.insert(0,str(updatedStuff))
        
            hints.destroy()




        hints = tk.Tk()
        hints.title('Hints')
        hints.configure(background='#2e5976')
        Font_tuple = ("Century Gothic", 12, "bold")
        typeSubmission.delete(0,END)
        letters_left = []

        incompleteWord =''
        
        
        for letter in alphabet:
            if globals()[letter].cget('bg') == 'light gray' and globals()[letter].cget('fg') != '#000001' or globals()[letter].cget('bg') == 'green' and globals()[letter].cget('fg') != '#000001':
                letters_left.append(globals()[letter].cget('text'))

        for i in spacedWordHint:
            incompleteWord += str(i)
        
        
        c = 0
        for hint in letters_left:
           addedWord = str(incompleteWord.replace('1',str(hint)))
           bigVariable = 'bigLabel' + str(c)
           
           globals()[bigVariable] = tk.Button(hints,text=addedWord, width= 15, height=1, command = lambda var = bigVariable:[addToList(var)])
           globals()[bigVariable] .configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
           globals()[bigVariable] .grid(row = c, column = 0, padx = 10,pady = 1)
           globals()[bigVariable].bind('<Button-3>', lambda event, newVar = bigVariable, newVar2 = hint: onRightClick(newVar,newVar2))

           c+=1

        hints.mainloop()
            


    #Creates a folder to store data with your computer name user
    def get_display_name():
        global storedName,submitLimit
        GetUserNameEx = ctypes.windll.secur32.GetUserNameExW
        NameDisplay = 3

        size = ctypes.pointer(ctypes.c_ulong(0))
        GetUserNameEx(NameDisplay, None, size)

        nameBuffer = ctypes.create_unicode_buffer(size.contents.value)
        GetUserNameEx(NameDisplay, nameBuffer, size)
        return (nameBuffer.value)

    ##This function is the submit button and what happens as you hit submit
    def submit(*args):
        global word_var,submitButton,typeSubmission,submitLimit

        word = word_var.get()
        

        if len(word) == 5 and word.isalpha():
            if word in listOfWords:
                submitButton.config(bg= 'green')
                typeSubmission.config(bg = 'light gray',fg = 'black')
                checkWord(word)


            else:
                typeSubmission.delete(0,END)
                typeSubmission.config(bg = 'red',fg = 'black')
                submitButton.config(bg= 'red')
                typeSubmission.focus()
                
            
        else:
            submitButton.config(bg= 'red')


    #IF YOU WIN - then make a window displaying new options
    def winner():
        global enter
        popup = tk.Tk()
        popup.title('WINNER')
        popup.configure(background='#2e5976')
        Font_tuple = ("Century Gothic", 12, "bold")


        winnerLabel = tk.Label(master=popup,text='Congrats! You won!', width=15, height=1)
        winnerLabel.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
        winnerLabel.grid(row=0, column = 0,columnspan = 3,pady = [10,1],padx = [1,1])

        howManyLabel = tk.Label(master=popup,text=str(enter +1)+'/6', width=15, height=1)
        howManyLabel.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
        howManyLabel.grid(row=1, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])


        badWord = tk.Button(master=popup,text='Bad Word?', width=15, height=1,command = lambda:[badStuff(),badWord.grid_forget()])
        badWord.configure(background='red', foreground = "black",font = ("Century Gothic", 11, "bold"))
        badWord.grid(row=2, column = 0,columnspan = 3,pady = [10,1],padx = [10,10])


        scores = tk.Button(master=popup,text='Check Scores', width=15, height=1, command = lambda: [scoreSheet()])
        scores.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
        scores.grid(row=3, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])

        replayGame = tk.Button(master=popup,text='Play Again', width=15, height=1, command = lambda: [popup.destroy(),restart()])
        replayGame.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
        replayGame.grid(row=4, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])
        
        popup.mainloop()




    ###SCORE SHEET

    #Keeps the scores and can pull and visualize the data
    def scoreSheet():
        global scores1,scores2,scores3,scores4,scores5,scores6,fullPath,finalScores,attempted,redacted_words,games_played

        numbers = [1,2,3,4,5,6]
        scorefile = fullPath+"\\UsedWords.txt"
        for row in open(scorefile, "r"):
            row = row.split('-')
            scoreScores.append(row[1])
            

        for score in scoreScores:
            score = score.split('\n')




            if 'Redacted' in score[0]:
                redacted_words.append(score[0])
                

            elif 'X' in score[0]:
                games_played.append(score[0])                
            
            elif int(score[0]) == 1:
                scores1.append(int(score[0]))
                
            elif int(score[0]) == 2:
                scores2.append(int(score[0]))

            elif int(score[0]) == 3:
                scores3.append(int(score[0]))

            elif int(score[0]) == 4:
                scores4.append(int(score[0]))

            elif int(score[0]) == 5:
                scores5.append(int(score[0]))

            elif int(score[0]) == 6:
                scores6.append(int(score[0]))

            
                
                
        finalScores = [len(scores1),len(scores2),len(scores3),len(scores4),len(scores5),len(scores6),len(games_played)]
            
        plt.rcParams["figure.figsize"] = [8.0,8.0]
        plt.rcParams["figure.autolayout"] = True
        bar_names = ['1','2','3','4','5','6','X']
        plt.bar(bar_names, finalScores)
        plt.title('Stats')
        plt.xlabel('Number of Tries')
        plt.ylabel('Guess Distribution')
        #plt.text(6,1,'Number Lost: '+str(len(games_played)))
        plt.text(7,0,'Words Redacted: ' +str(len(redacted_words)))
        plt.show()
            



    #######

    ##This function checks to see if the word is in it and then breaks up the letters to assign it a color (gray,yellow,green)
    def checkWord(w):
        global updatedWord,listedWinWord,winWord,enter,typeSubmission,suggestions,spacedWordHint,finished
        spacedWordHint = []
        updatedWord = list(w)

        count = 0
        finished = 0
        for space in allSpaces:
            if globals()[space]['state'] == 'normal':
                globals()[space].config(text = updatedWord[count], state = 'disabled',disabledforeground = 'black')

                if updatedWord[count] in winWord:
                    
                    if updatedWord[count] == listedWinWord[count]:
                        globals()[space].config(bg= 'green')
                        turnColor = updatedWord[count] + 'Button'
                        globals()[turnColor].config(bg= 'green')
                        spacedWordHint.append(updatedWord[count])
                        finished +=1
                        
                    else:
                        globals()[space].config(bg= 'yellow')
                        turnColor = updatedWord[count] + 'Button'
                        globals()[turnColor].config(bg= 'green')
                        spacedWordHint.append('1')

                    
                else:
                    globals()[space].config(bg= '#565656')
                    turnColor = updatedWord[count] + 'Button'
                    globals()[turnColor].config(bg= '#565656')
                    spacedWordHint.append('1')
          
                count+=1
                ######################################################

        if finished == 4:
            enter+=1
            suggestions.grid(row=8, column = 3,columnspan = 4,pady = [0,10])
            typeSubmission.delete(0,END)
            unlock()
            
            
            

            
        elif finished == 5:
            typeSubmission.delete(0,END)
            suggestions.grid_forget()
            file.write(winWord+' - '+str(enter + 1) +'\n')
            file.close()
        
            
            winner()
        else:
            enter+=1
            typeSubmission.delete(0,END)
            suggestions.grid_forget()
            unlock()
                




    #Grabs the row and column positioning
    def boardPos(var):
        global row,column
        
        ####print('---------------')
        variable = globals()[var]
        row    = variable.grid_info()['row'] 
        column = variable.grid_info()['column']
        ####print(str(row)+':'+str(column))



    #Places the letters
    def letterPlacement(t):
        global allSpaces,row,column

        currentWord = ''



        

    #Unlocks the next round. This allows for the game to go row by row. Guess 1 -> Guess 2 -> Guess 3...etc
    def unlock():

        global allSpaces,row,column, enter,winWord
        if enter == 0:
            for i in range(5):
                variable = 'button0'+str(i)
                globals()[variable]['state'] = 'normal'


        if enter == 1:
            for i in range(5):
                variable = 'button1'+str(i)
                globals()[variable]['state'] = 'normal'

        if enter == 2:
            for i in range(5):
                variable = 'button2'+str(i)
                globals()[variable]['state'] = 'normal'

        if enter == 3:
            for i in range(5):
                variable = 'button3'+str(i)
                globals()[variable]['state'] = 'normal'

        if enter == 4:
            for i in range(5):
                variable = 'button4'+str(i)
                globals()[variable]['state'] = 'normal'

        if enter == 5:

            
            for i in range(5):
                variable = 'button5'+str(i)
                globals()[variable]['state'] = 'normal'

        if enter > 5: #If you go over 5 Guesses this is where you lose
            file.write(winWord+' - '+'X\n')
            file.close()
            
            popup = tk.Tk()
            popup.title('You Lost')
            popup.configure(background='#2e5976')
            Font_tuple = ("Century Gothic", 12, "bold")

            wordLabel = tk.Label(master=popup,text=str(winWord), width=25, height=1)
            wordLabel.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
            wordLabel.grid(row=0, column = 0, columnspan = 3,pady = [10,1],padx = [1,1]) 


            winnerLabel = tk.Label(master=popup,text='You Lost!', width=25, height=1)
            winnerLabel.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
            winnerLabel.grid(row=1, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])

            howManyLabel = tk.Label(master=popup,text='X', width=25, height=1)
            howManyLabel.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
            howManyLabel.grid(row=2, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])


            badWord = tk.Button(master=popup,text='Bad Word', state = 'normal',width=15, height=1,command = lambda:[badStuff(),badWord.grid_forget()])
            badWord.configure(background='red', foreground = "black",font = ("Century Gothic", 11, "bold"))
            badWord.grid(row=3, column = 0, columnspan = 3,pady = [10,1],padx = [10,10])

            replayGame = tk.Button(master=popup,text='Play Again', width=15, height=1, command = lambda: [popup.destroy(),restart()])
            replayGame.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
            replayGame.grid(row=4, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])

            scores = tk.Button(master=popup,text='Check Scores', width=15, height=1, command = lambda: [scoreSheet()])
            scores.configure(background='#2e5976', foreground = "black",font = ("Century Gothic", 11, "bold"))
            scores.grid(row=5, column = 0, columnspan = 3,pady = [10,1],padx = [1,1])


            popup.mainloop()





    ##This function  allows User rejected words- Is it a bad word? If so remove it for the future
    def badStuff():
        global winWord,unlock,badWord

        word_list = []
        
        with open("X:\Ticket System\SCRIPTS\Old Test Cases\Word\word.txt", "r") as f:
            lines = f.readlines()
        with open("X:\Ticket System\SCRIPTS\Old Test Cases\Word\word.txt", "w") as f:
            for line in lines:
                if line.strip("\n") != winWord:
                    f.write(line)
        
#####USED WORD FILE
        with open (fullPath+"\\UsedWords.txt", 'r') as f:
            words = f.readlines()

        for i in words:
            word_list.append(i)
        del word_list[-1]

        #print(word_list)
        with open(fullPath+"\\UsedWords.txt", "w") as f:
            for words in word_list:
                f.write(words)
            
     
        with open(fullPath+"\\UsedWords.txt", "a+") as f:
            if line.strip("\n") != winWord:
                f.write(winWord + ' - Redacted\n')


            
        
        





            

        




               
    ##########END Functions############



    fullPath =str(get_display_name())

    isExist = os.path.exists(fullPath)

    if not isExist:
      
      # Create a new directory because it does not exist 
      os.makedirs(fullPath)


    file = open(fullPath+"\\UsedWords.txt", "a+")




    ####################CREATE A BOARD####################
    for i,  row in enumerate(range(rows)):
        for j,  column in enumerate(range(columns)):


            variable = str(i)+str(j)
            standardVar = 'button'+variable
            ######print(standardVar)
            
            globals()[standardVar] = tk.Button(master=window,text='', width=3, height=1, borderwidth = 2, relief = 'solid', state = 'disabled',command = lambda var = standardVar:[boardPos(var)])
            globals()[standardVar].configure(background='#2e6276', foreground = "black",font = ("Century Gothic", 11, "bold"))
            globals()[standardVar].grid(row=i, column = j+2,columnspan =2)


            allSpaces.append(standardVar)







    submitButton= tk.Button(master=window,text='submit', width=6, height=1, borderwidth = 2, relief = 'solid', command = lambda: submit())
    submitButton.configure(background='green', foreground = "black",font = ("Century Gothic", 11, "bold"))
    submitButton.grid(row=7, column = 3,columnspan = 4,pady = [0,10])



    suggestions= tk.Button(master=window,text='help', width=6, height=1, borderwidth = 2, relief = 'solid', command = lambda: suggest())
    suggestions.configure(background='yellow', foreground = "black",font = ("Century Gothic", 11, "bold"))
    suggestions.grid(row=8, column = 3,columnspan = 4,pady = [0,10])
    suggestions.grid_forget()


    typeSubmission = tk.Entry(window, bg = 'light gray', textvariable = word_var, font = ("Century Gothic", 11, "bold"))
    typeSubmission.grid(row= 6, column =1, columnspan = 8,pady = [15,5])
    typeSubmission.focus()
    typeSubmission.bind('<Return>',submit)






    unlock()




























#########################################THE LETTERS TO SEE WHICH ONES ARE available

    ###FIRST ROW OF LETTERS

    qButton = tk.Label(master=window,text='q', width=3, height=1, borderwidth = 2, relief = 'solid')
    qButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    qButton.grid(row = 9, column = 0,pady = [10,1],padx = [1,1])

    wButton = tk.Label(master=window,text='w', width=3, height=1, borderwidth = 2, relief = 'solid')
    wButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    wButton.grid(row = 9, column = 1,pady = [10,1],padx = [1,1])


    eButton = tk.Label(master=window,text='e', width=3, height=1, borderwidth = 2, relief = 'solid')
    eButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    eButton.grid(row = 9, column = 2,pady = [10,1],padx = [1,1])


    rButton = tk.Label(master=window,text='r', width=3, height=1, borderwidth = 2, relief = 'solid')
    rButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    rButton.grid(row = 9, column = 3,pady = [10,1],padx = [1,1])

    tButton = tk.Label(master=window,text='t', width=3, height=1, borderwidth = 2, relief = 'solid')
    tButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    tButton.grid(row = 9, column = 4,pady = [10,1],padx = [1,1])

    yButton = tk.Label(master=window,text='y', width=3, height=1, borderwidth = 2, relief = 'solid')
    yButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    yButton.grid(row = 9, column = 5,pady = [10,1],padx = [1,1])

    uButton = tk.Label(master=window,text='u', width=3, height=1, borderwidth = 2, relief = 'solid')
    uButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    uButton.grid(row = 9, column = 6,pady = [10,1],padx = [1,1])


    iButton = tk.Label(master=window,text='i', width=3, height=1, borderwidth = 2, relief = 'solid')
    iButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    iButton.grid(row = 9, column = 7,pady = [10,1],padx = [1,1])

    oButton = tk.Label(master=window,text='o', width=3, height=1, borderwidth = 2, relief = 'solid')
    oButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    oButton.grid(row = 9, column = 8,pady = [10,1],padx = [1,1])

    pButton = tk.Label(master=window,text='p', width=3, height=1, borderwidth = 2, relief = 'solid')
    pButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    pButton.grid(row = 9, column = 9,pady = [10,1],padx = [1,1])


    ###Second ROW OF LETTERS.
    aButton = tk.Label(master=window,text='a', width=3, height=1, borderwidth = 2, relief = 'solid')
    aButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    aButton.grid(row = 10, column = 0,columnspan = 2,pady = [1,1],padx = [1,1])

    sButton = tk.Label(master=window,text='s', width=3, height=1, borderwidth = 2, relief = 'solid')
    sButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    sButton.grid(row = 10, column = 1,columnspan = 2,pady = [1,1],padx = [1,1])

    dButton = tk.Label(master=window,text='d', width=3, height=1, borderwidth = 2, relief = 'solid')
    dButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    dButton.grid(row = 10, column = 2,columnspan = 2,pady = [1,1],padx = [1,1])

    fButton = tk.Label(master=window,text='f', width=3, height=1, borderwidth = 2, relief = 'solid')
    fButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    fButton.grid(row = 10, column = 3,columnspan = 2,pady = [1,1],padx = [1,1])

    gButton = tk.Label(master=window,text='g', width=3, height=1, borderwidth = 2, relief = 'solid')
    gButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    gButton.grid(row = 10, column = 4,columnspan = 2,pady = [1,1],padx = [1,1])

    hButton = tk.Label(master=window,text='h', width=3, height=1, borderwidth = 2, relief = 'solid')
    hButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    hButton.grid(row = 10, column = 5,columnspan = 2,pady = [1,1],padx = [1,1])

    jButton = tk.Label(master=window,text='j', width=3, height=1, borderwidth = 2, relief = 'solid')
    jButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    jButton.grid(row = 10, column = 6,columnspan = 2,pady = [1,1],padx = [1,1])

    kButton = tk.Label(master=window,text='k', width=3, height=1, borderwidth = 2, relief = 'solid')
    kButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    kButton.grid(row = 10, column = 7,columnspan = 2,pady = [1,1],padx = [1,1])

    lButton = tk.Label(master=window,text='l', width=3, height=1, borderwidth = 2, relief = 'solid')
    lButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    lButton.grid(row = 10, column = 8,columnspan = 2,pady = [1,1],padx = [1,1])


    ###Third ROW OF LETTERS


    zButton = tk.Label(master=window,text='z', width=3, height=1, borderwidth = 2, relief = 'solid')
    zButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    zButton.grid(row = 11, column = 0,pady = [1,10],columnspan = 3,padx = [1,1])

    xButton = tk.Label(master=window,text='x', width=3, height=1, borderwidth = 2, relief = 'solid')
    xButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    xButton.grid(row = 11, column = 1,pady = [1,10],columnspan = 3,padx = [1,1])

    cButton = tk.Label(master=window,text='c', width=3, height=1, borderwidth = 2, relief = 'solid')
    cButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    cButton.grid(row = 11, column = 2,pady = [1,10],columnspan = 3,padx = [1,1])


    vButton = tk.Label(master=window,text='v', width=3, height=1, borderwidth = 2, relief = 'solid')
    vButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    vButton.grid(row = 11, column= 3,pady = [1,10],columnspan = 4,padx = [1,1])

    bButton = tk.Label(master=window,text='b', width=3, height=1, borderwidth = 2, relief = 'solid')
    bButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    bButton.grid(row = 11, column = 5,pady = [1,10],columnspan = 3,padx = [1,1])

    nButton = tk.Label(master=window,text='n', width=3, height=1, borderwidth = 2, relief = 'solid')
    nButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    nButton.grid(row = 11, column = 6,pady = [1,10],columnspan = 3,padx = [1,1])

    mButton = tk.Label(master=window,text='m', width=3, height=1, borderwidth = 2, relief = 'solid')
    mButton.configure(background='light gray', foreground = "black",font = ("Century Gothic", 11, "bold"))
    mButton.grid(row = 11, column = 7,pady = [1,10],columnspan = 3,padx = [1,1])











        



    window.mainloop()
play()


    


















    


